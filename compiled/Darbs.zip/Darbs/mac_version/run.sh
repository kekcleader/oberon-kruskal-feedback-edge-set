./vinnipuh < 'in.txt'

# Variant:
#./vinnipuh < 'in.txt' > 'out.txt'
