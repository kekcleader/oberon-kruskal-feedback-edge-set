Install the compiler using Homebrew like this:

brew tap vostok-space/oberon && brew install vostok
