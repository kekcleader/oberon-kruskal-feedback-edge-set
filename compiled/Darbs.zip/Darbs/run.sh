ost to-bin 'VinniPuh.Do' vinnipuh -m .

./vinnipuh < 'in.txt' > 'out.txt'

# Variant:
#./vinnipuh < 'in.txt'
