To recompile, download and install Free Oberon from https://free.oberon.org
and compile VinniPuh.Mod either using the Free Oberon IDE or by using the `fob` command:

fob VinniPuh.Mod

Run VinniPuh.Mod from command prompt like this:

VinniPuh.exe < in.txt > out.txt

This will use the file `in.txt` as input of the program, and the results will appear in `out.txt`.
